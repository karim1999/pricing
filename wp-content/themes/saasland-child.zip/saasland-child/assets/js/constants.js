module.exports = Object.freeze({
  CLIENT_ID: "1000.FHEYBJ33G2P7SGH3QCLX6SWA3QVEAI",
  CLIENT_SECRET: "c17898d6823702067e5e9f82faf48e1bef0a89da59",
  REFRESH_TOKEN:
    "1000.bb96de0f63d4ef48ab85f57e07acb82a.44334599de89a0fa62d849e0c7cf2719",
  URL:
    "https://karim-cors.herokuapp.com/https://creator.zoho.com/api/v2/gammalearn/swiftassess"
});
